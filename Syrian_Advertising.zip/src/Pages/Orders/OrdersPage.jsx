import React from 'react'
import OrdersContainer from '../../Components/Orders/OrdersContainer'

const OrdersPage = () => {
  return (
    <div>
      <OrdersContainer />
    </div>
  )
}

export default OrdersPage 