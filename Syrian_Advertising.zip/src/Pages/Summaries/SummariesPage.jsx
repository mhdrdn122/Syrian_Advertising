import React from 'react'
import SummariesContainer from '../../Components/Summaries/SummariesContainer'

const SummariesPage = () => {
  return (
    <div>
        <SummariesContainer />
    </div>
  )
}

export default SummariesPage