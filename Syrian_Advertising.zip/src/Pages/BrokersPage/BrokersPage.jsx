import React from 'react'
import BrokersContainer from '../../Components/Brokers/BrokersContainer'

const BrokersPage = () => {
  return (
    <div>
      <BrokersContainer />
    </div>
  )
}

export default BrokersPage