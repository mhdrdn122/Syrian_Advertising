import React from 'react'
import TemplatesContainer from '../../Components/Templates/TemplatesContainer'

const TemplatesPage = () => {
  return (
    <div>
        <TemplatesContainer />
    </div>
  )
}

export default TemplatesPage