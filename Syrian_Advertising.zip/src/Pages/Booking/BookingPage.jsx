import React from 'react'
import BookingContainer from '../../Components/Booking/BookingContainer'

const BookingPage = () => {
  return (
    <div>
        <BookingContainer />
    </div>
  )
}

export default BookingPage