import React from 'react'
import PaymentsContainer from '../../Components/Payments/PaymentsContainer'

const PaymentsPages = () => {
  return (
    <div>
        <PaymentsContainer />
    </div>
  )
}

export default PaymentsPages