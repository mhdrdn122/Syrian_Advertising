import React from 'react'
import ReportsContainer from '../../Components/Report/ReportsContainer'

const ReportsPage = () => {
  return (
    <div>
        <ReportsContainer />
    </div>
  )
}

export default ReportsPage