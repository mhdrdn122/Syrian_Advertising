import React from 'react'
import RegionsCityContainer from '../../Components/RegionsCity/RegionsCityContainer'

const RegionsCityPage = () => {
  return (
    <div>
        <RegionsCityContainer />
    </div>
  )
}

export default RegionsCityPage