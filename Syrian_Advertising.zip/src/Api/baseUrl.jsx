// export const BASE_URL = "https://syrback.le.sy/api" 

export const BASE_URL = "https://road.levantmenu.ae/api" 

// export const BASE_URL = "https://road.medical-clinic.serv00.net/api" 
// export const BASE_URL = "https://road.levantmenu.ae/api" 





