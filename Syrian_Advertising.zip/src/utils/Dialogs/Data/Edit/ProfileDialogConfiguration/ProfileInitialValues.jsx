export const ProfileInitialValues = {
  full_name: "",
  username: "",
  phone_number: "",
  address: "",
  email:"",
  password:"",
}; 