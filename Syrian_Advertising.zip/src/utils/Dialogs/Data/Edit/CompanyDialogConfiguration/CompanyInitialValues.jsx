export const CompanyInitialValues = {
  name: "",
  commercial_registration_number: null,
  address: "",
  description: "",
  about_us:"",
  contract_note:"",
}; 