export const CustomerInitialValues = {
  name: "",
  company_name: "",
  address: "",
  phone_number: "",
  commercial_registration_number:""
  
  // discount: "",
};