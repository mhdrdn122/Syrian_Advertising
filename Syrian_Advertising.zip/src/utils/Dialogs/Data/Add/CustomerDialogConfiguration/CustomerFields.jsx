export const CustomerFields = [
  { name: "full_name", label: "الاسم", dir: "rtl" },
  { name: "company_name", label: "اسم الشركة" },
  { name: "address", label: "الموقع" },
  { name: "phone_number", label: "رقم الهاتف" },
  { name: "commercial_registration_number", label: "رقم السجل التجاري" },

  // { name: "discount", label: "الخصم" },

];