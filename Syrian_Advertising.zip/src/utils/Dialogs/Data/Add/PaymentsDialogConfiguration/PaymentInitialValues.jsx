export const PaymentInitialValues = {
  paid: "",
  payment_number: "",
  customer_id: "",
  payment_image: null,
};