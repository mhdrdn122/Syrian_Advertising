export const roadSignInitialValues = {
  city_id: "",
  region_id: "",
  place: "",
  directions: "",
  number: "",
  faces_number: "",
  advertising_meters: "",
  printing_meters: "",
  template_id: "",
  is_available: "",
};