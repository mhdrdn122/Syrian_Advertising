export const BrokerInitialValues = {
  name: "",
  number: "",
  discount: "",
};