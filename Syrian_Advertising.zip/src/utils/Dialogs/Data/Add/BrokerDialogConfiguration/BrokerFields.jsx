export const BrokerFields = [
  { name: "full_name", label: "الاسم", dir: "rtl" },
  { name: "number", label: "رقم الهاتف" },
  { name: "discount", label: "الخصم" },
];