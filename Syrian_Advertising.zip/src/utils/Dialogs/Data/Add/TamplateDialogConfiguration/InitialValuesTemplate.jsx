export const TemplateInitialValues = {
  model: "",
  type: "",
  size: "",
  advertising_space: "",
  printing_space: "",
  products: [
    { price: "", type: 1 },
    { price: "", type: 2 },
    { price: "", type: 3 },
  ],
};