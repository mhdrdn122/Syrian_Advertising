import './LoadingGet.css'

const LoadingGet = () => {
  return (
    <div class="loader"></div>
    
  )
}

export default LoadingGet